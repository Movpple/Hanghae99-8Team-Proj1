# Name: Catalina Pradilla Rocha

# GitHub page: 
https://github.com/cattapr

# GitHub repository: 
https://github.com/cattapr/Cocktail-App-with-Javascript-and-Ajax

# Description of the app: 
This app is a fun way to mix cocktails on a cocktailparty. Everyone can use it, either search after a specific drink of your desire or even more fun to get a drink after your mood! 

# Libaries I used: 
Sass and Bootstrap.

# API links: 
https://www.thecocktaildb.com/api.php
Search cocktail by name
https://www.thecocktaildb.com/api/json/v1/1/search.php?s=margarita
Lookup a random cocktail
https://www.thecocktaildb.com/api/json/v1/1/random.php
Imagelink:
https://www.thecocktaildb.com/images/ingredients/ice-Medium.png

# API:
 The cocktaildb has a number of api to use for their cocktaillist. In my app I have the link to get random drink and the one where I can get a cocktail by its name.

# Things to improve: 
Make the app more specific when choosing random drinks. For instance, code different cocktails to be shown on the different buttonmoods. In that way make the app understand the user more. 


